"use strict";
cc._RF.push(module, 'e9b96bkSQtDWIGL/GxT0f0m', 'Enemy');
// scripts/Enemy.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var BulletCollision_1 = require("./BulletCollision");
var AircraftBase_1 = require("./AircraftBase");
var Game_1 = require("./Game");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Enemy = /** @class */ (function (_super) {
    __extends(Enemy, _super);
    function Enemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // LIFE-CYCLE CALLBACKS:
        _this.bulletSpeed = 500;
        _this.fireTime = 0.5;
        _this.fireTimeCount = 0;
        return _this;
    }
    Enemy.prototype.onLoad = function () {
        this.canvas = cc.find("Canvas");
    };
    Enemy.prototype.start = function () {
    };
    Enemy.prototype.update = function (dt) {
        this.fire(dt);
    };
    Enemy.prototype.fire = function (dt) {
        this.fireTimeCount += dt;
        if (this.fireTimeCount >= this.fireTime) {
            this.fireTimeCount = 0;
            var bullet = cc.instantiate(this.bullet);
            bullet.setParent(this.canvas);
            bullet.setPosition(this.node.position);
            bullet.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, -this.bulletSpeed);
            bullet.addComponent(BulletCollision_1.default).enemy = "Player";
        }
    };
    Enemy.prototype.OnDestroy = function () {
        cc.log("enemy");
        this.lift--;
        if (this.lift <= 0) {
            this.node.active = false;
            var game = cc.find("Canvas/Game").getComponent(Game_1.default);
            game.addScore(1);
        }
    };
    __decorate([
        property(cc.Prefab)
    ], Enemy.prototype, "bullet", void 0);
    Enemy = __decorate([
        ccclass
    ], Enemy);
    return Enemy;
}(AircraftBase_1.default));
exports.default = Enemy;

cc._RF.pop();