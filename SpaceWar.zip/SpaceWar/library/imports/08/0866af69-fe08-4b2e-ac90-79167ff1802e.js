"use strict";
cc._RF.push(module, '0866a9p/ghLLqyQeRZ/8YAu', 'IDestroy');
// scripts/IDestroy.ts



cc._RF.pop();