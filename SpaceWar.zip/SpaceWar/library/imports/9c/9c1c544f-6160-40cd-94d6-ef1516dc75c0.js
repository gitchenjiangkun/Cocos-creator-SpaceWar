"use strict";
cc._RF.push(module, '9c1c5RPYWBAzZTW7xUW3HXA', 'Game');
// scripts/Game.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Player_1 = require("./Player");
var Enemy_1 = require("./Enemy");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Game = /** @class */ (function (_super) {
    __extends(Game, _super);
    function Game() {
        // LIFE-CYCLE CALLBACKS:
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.enemyList = [null, null, null, null, null, null];
        _this.enemyCount = 0;
        _this.scoreNum = 0;
        return _this;
    }
    Game.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
        cc.director.getPhysicsManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        this.canvas = cc.find("Canvas");
        this.game = cc.find("Canvas/Game");
        this.player = cc.find("Canvas/Game/Player");
        this.score = cc.find("Canvas/Game/Score");
    };
    Game.prototype.onEnable = function () {
        this.insEnemy();
        this.restartEnemy();
        this.restartPlayer();
        this.restartScore();
    };
    // start () {
    // }
    Game.prototype.update = function (dt) {
        this.detectionEnemy();
    };
    Game.prototype.insEnemy = function () {
        for (var i = this.enemyCount; i < this.enemyList.length; i++) {
            var enemy = cc.instantiate(this.enemyPrefab);
            this.enemyList[i] = enemy;
            this.enemyCount++;
        }
    };
    Game.prototype.detectionEnemy = function () {
        for (var i = 0; i < this.enemyList.length; i++) {
            if (this.enemyList[i] != null) {
                var x = Math.abs(this.enemyList[i].position.x);
                var y = this.enemyList[i].position.y;
                if (x > this.canvas.width / 2 + 100) {
                    this.setEnemy(this.enemyList[i]);
                }
                if (y < -this.canvas.height / 2) {
                    this.setEnemy(this.enemyList[i]);
                }
                if (this.enemyList[i].active == false) {
                    this.setEnemy(this.enemyList[i]);
                }
            }
        }
    };
    Game.prototype.setEnemy = function (enemy) {
        var x = this.canvas.width / 2;
        var y = this.canvas.height / 2;
        enemy.active = true;
        enemy.setParent(this.game);
        enemy.setPosition(this.random(-x, x), y, 0);
        enemy.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
        enemy.getComponent(Enemy_1.default).lift = 1;
    };
    Game.prototype.restartEnemy = function () {
        for (var i = 0; i < this.enemyList.length; i++) {
            if (this.enemyList[i] != null) {
                this.setEnemy(this.enemyList[i]);
            }
        }
    };
    Game.prototype.restartPlayer = function () {
        this.player.active = true;
        this.player.setPosition(cc.v2(0, -260));
        this.player.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
        this.player.getComponent(Player_1.default).enabled = true;
        this.player.getComponent(Player_1.default).lift = 3;
    };
    Game.prototype.restartScore = function () {
        this.scoreNum = 0;
        this.score.getComponent(cc.Label).string = "分数 : " + this.scoreNum.toString();
    };
    Game.prototype.addScore = function (num) {
        this.scoreNum += num;
        this.score.getComponent(cc.Label).string = "分数 : " + this.scoreNum.toString();
    };
    Game.prototype.random = function (min, max) {
        var r = Math.random();
        var num = 0;
        if (r < 0.5) {
            num = Math.random() * min - 50;
        }
        else {
            num = Math.random() * max + 50;
        }
        return num;
    };
    __decorate([
        property(cc.Prefab)
    ], Game.prototype, "enemyPrefab", void 0);
    Game = __decorate([
        ccclass
    ], Game);
    return Game;
}(cc.Component));
exports.default = Game;

cc._RF.pop();