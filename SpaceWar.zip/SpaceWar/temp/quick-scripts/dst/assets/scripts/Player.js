
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd7b20siHjFM75TF8OM+0zh8', 'Player');
// scripts/Player.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var BulletCollision_1 = require("./BulletCollision");
var AircraftBase_1 = require("./AircraftBase");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bulletSpeed = 500;
        _this.fireTime = 0.2;
        _this.fireTimeCount = 0;
        _this.speed = 300;
        return _this;
    }
    Player_1 = Player;
    Player.prototype.onLoad = function () {
        this.canvas = cc.find("Canvas");
        this.player = cc.find("Canvas/Game/Player");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.keyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.keyUp, this);
    };
    Player.prototype.start = function () {
    };
    Player.prototype.update = function (dt) {
        this.move(dt);
        this.fire(dt);
    };
    Player.prototype.move = function (dt) {
        if (this.up == true) {
            var num = this.player.y += dt * this.speed;
            var num2 = this.canvas.height / 2;
            num = this.clamp(num, -num2, num2);
            this.player.y = num;
        }
        if (this.down == true) {
            var num = this.player.y -= dt * this.speed;
            var num2 = this.canvas.height / 2;
            num = this.clamp(num, -num2, num2);
            this.player.y = num;
        }
        if (this.left == true) {
            var num = this.player.x -= dt * this.speed;
            var num2 = this.canvas.width / 2;
            num = this.clamp(num, -num2, num2);
            this.player.x = num;
        }
        if (this.right == true) {
            var num = this.player.x += dt * this.speed;
            var num2 = this.canvas.width / 2;
            num = this.clamp(num, -num2, num2);
            this.player.x = num;
        }
    };
    Player.prototype.keyDown = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.w:
                this.up = true;
                break;
            case cc.macro.KEY.s:
                this.down = true;
                break;
            case cc.macro.KEY.a:
                this.left = true;
                break;
            case cc.macro.KEY.d:
                this.right = true;
                break;
        }
    };
    Player.prototype.keyUp = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.w:
                this.up = false;
                break;
            case cc.macro.KEY.s:
                this.down = false;
                break;
            case cc.macro.KEY.a:
                this.left = false;
                break;
            case cc.macro.KEY.d:
                this.right = false;
                break;
        }
    };
    Player.prototype.clamp = function (value, min, max) {
        var num = 0;
        if (value >= max) {
            num = max;
        }
        else if (value <= min) {
            num = min;
        }
        else {
            num = value;
        }
        return num;
    };
    Player.prototype.fire = function (dt) {
        this.fireTimeCount += dt;
        if (this.fireTimeCount >= this.fireTime) {
            this.fireTimeCount = 0;
            var bullet = cc.instantiate(this.bullet);
            bullet.setParent(this.canvas);
            bullet.setPosition(this.player.position);
            bullet.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, this.bulletSpeed);
            bullet.addComponent(BulletCollision_1.default).enemy = "Enemy";
        }
    };
    Player.prototype.OnDestroy = function () {
        cc.log("player");
        this.lift--;
        if (this.lift <= 0) {
            this.node.active = false;
            this.node.getComponent(Player_1).enabled = false;
            cc.find("Canvas/Restart").active = true;
        }
    };
    var Player_1;
    __decorate([
        property(cc.Prefab)
    ], Player.prototype, "bullet", void 0);
    Player = Player_1 = __decorate([
        ccclass
    ], Player);
    return Player;
}(AircraftBase_1.default));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcUGxheWVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWxGLHFEQUFnRDtBQUNoRCwrQ0FBMEM7QUFFcEMsSUFBQSxrQkFBbUMsRUFBbEMsb0JBQU8sRUFBRSxzQkFBeUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQURoRDtRQUFBLHFFQXFJQztRQXRIRyxpQkFBVyxHQUFVLEdBQUcsQ0FBQztRQUN6QixjQUFRLEdBQVUsR0FBRyxDQUFDO1FBQ3RCLG1CQUFhLEdBQVUsQ0FBQyxDQUFDO1FBRXpCLFdBQUssR0FBVSxHQUFHLENBQUM7O0lBa0h2QixDQUFDO2VBcElvQixNQUFNO0lBbUJ0Qix1QkFBTSxHQUFOO1FBQ0csSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQzVDLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pFLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRixzQkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVBLHVCQUFNLEdBQU4sVUFBUSxFQUFFO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDakIsQ0FBQztJQUVGLHFCQUFJLEdBQUosVUFBSyxFQUFTO1FBQ1YsSUFBRyxJQUFJLENBQUMsRUFBRSxJQUFJLElBQUksRUFBQztZQUNmLElBQUksR0FBRyxHQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ2xELElBQUksSUFBSSxHQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUN6QyxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3ZCO1FBQ0QsSUFBRyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBQztZQUNqQixJQUFJLEdBQUcsR0FBVSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNsRCxJQUFJLElBQUksR0FBVSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDekMsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ25DLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUN2QjtRQUNELElBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUM7WUFDakIsSUFBSSxHQUFHLEdBQVUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDbEQsSUFBSSxJQUFJLEdBQVUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1lBQ3hDLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNuQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDdkI7UUFDRCxJQUFHLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxFQUFDO1lBQ2xCLElBQUksR0FBRyxHQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ2xELElBQUksSUFBSSxHQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztZQUN4QyxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVELHdCQUFPLEdBQVAsVUFBUSxLQUFLO1FBQ1QsUUFBTyxLQUFLLENBQUMsT0FBTyxFQUFDO1lBQ2pCLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZixJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQztnQkFDZixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNsQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRUQsc0JBQUssR0FBTCxVQUFNLEtBQUs7UUFDUCxRQUFPLEtBQUssQ0FBQyxPQUFPLEVBQUM7WUFDakIsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxFQUFFLEdBQUcsS0FBSyxDQUFDO2dCQUNoQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO2dCQUNsQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO2dCQUNsQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUNuQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRUQsc0JBQUssR0FBTCxVQUFNLEtBQVksRUFBRSxHQUFVLEVBQUcsR0FBVTtRQUN2QyxJQUFJLEdBQUcsR0FBVSxDQUFDLENBQUM7UUFDbkIsSUFBRyxLQUFLLElBQUksR0FBRyxFQUFDO1lBQ1osR0FBRyxHQUFHLEdBQUcsQ0FBQztTQUNiO2FBQ0ksSUFBRyxLQUFLLElBQUksR0FBRyxFQUFDO1lBQ2pCLEdBQUcsR0FBRyxHQUFHLENBQUM7U0FDYjthQUNHO1lBQ0EsR0FBRyxHQUFHLEtBQUssQ0FBQztTQUNmO1FBQ0QsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0lBRUQscUJBQUksR0FBSixVQUFLLEVBQVM7UUFDVixJQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsQ0FBQztRQUN6QixJQUFHLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBQztZQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztZQUN2QixJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM5QixNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDekMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM5RSxNQUFNLENBQUMsWUFBWSxDQUFDLHlCQUFlLENBQUMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1NBQ3hEO0lBQ0wsQ0FBQztJQUVELDBCQUFTLEdBQVQ7UUFDSSxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNaLElBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLEVBQUM7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBTSxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUMvQyxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUMzQztJQUNMLENBQUM7O0lBL0hEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7MENBQ0g7SUFIQSxNQUFNO1FBRDFCLE9BQU87T0FDYSxNQUFNLENBb0kxQjtJQUFELGFBQUM7Q0FwSUQsQUFvSUMsQ0FwSW1DLHNCQUFZLEdBb0kvQztrQkFwSW9CLE1BQU0iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5pbXBvcnQgQnVsbGV0Q29sbGlzaW9uIGZyb20gXCIuL0J1bGxldENvbGxpc2lvblwiO1xyXG5pbXBvcnQgQWlyY3JhZnRCYXNlIGZyb20gXCIuL0FpcmNyYWZ0QmFzZVwiO1xyXG5cclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQbGF5ZXIgZXh0ZW5kcyBBaXJjcmFmdEJhc2Uge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBidWxsZXQ6Y2MuUHJlZmFiO1xyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcbiAgICBcclxuICAgIHVwOmJvb2xlYW47XHJcbiAgICBkb3duOmJvb2xlYW47XHJcbiAgICBsZWZ0OmJvb2xlYW47XHJcbiAgICByaWdodDpib29sZWFuO1xyXG5cclxuICAgIGNhbnZhczpjYy5Ob2RlO1xyXG4gICAgcGxheWVyOmNjLk5vZGU7XHJcblxyXG4gICAgYnVsbGV0U3BlZWQ6bnVtYmVyID0gNTAwO1xyXG4gICAgZmlyZVRpbWU6bnVtYmVyID0gMC4yO1xyXG4gICAgZmlyZVRpbWVDb3VudDpudW1iZXIgPSAwO1xyXG5cclxuICAgIHNwZWVkOm51bWJlciA9IDMwMDtcclxuICAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuY2FudmFzID0gY2MuZmluZChcIkNhbnZhc1wiKTtcclxuICAgICAgICB0aGlzLnBsYXllciA9IGNjLmZpbmQoXCJDYW52YXMvR2FtZS9QbGF5ZXJcIik7XHJcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLmtleURvd24sIHRoaXMpO1xyXG4gICAgICAgIGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfVVAsIHRoaXMua2V5VXAsIHRoaXMpO1xyXG4gICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdGhpcy5tb3ZlKGR0KTtcclxuICAgICAgICB0aGlzLmZpcmUoZHQpO1xyXG4gICAgIH1cclxuXHJcbiAgICBtb3ZlKGR0Om51bWJlcil7XHJcbiAgICAgICAgaWYodGhpcy51cCA9PSB0cnVlKXtcclxuICAgICAgICAgICAgdmFyIG51bTpudW1iZXIgPSB0aGlzLnBsYXllci55ICs9IGR0ICogdGhpcy5zcGVlZDtcclxuICAgICAgICAgICAgdmFyIG51bTI6bnVtYmVyID0gdGhpcy5jYW52YXMuaGVpZ2h0IC8gMjtcclxuICAgICAgICAgICAgbnVtID0gdGhpcy5jbGFtcChudW0sIC1udW0yLCBudW0yKTtcclxuICAgICAgICAgICAgdGhpcy5wbGF5ZXIueSA9IG51bTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5kb3duID09IHRydWUpe1xyXG4gICAgICAgICAgICB2YXIgbnVtOm51bWJlciA9IHRoaXMucGxheWVyLnkgLT0gZHQgKiB0aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbnVtMjpudW1iZXIgPSB0aGlzLmNhbnZhcy5oZWlnaHQgLyAyO1xyXG4gICAgICAgICAgICBudW0gPSB0aGlzLmNsYW1wKG51bSwgLW51bTIsIG51bTIpO1xyXG4gICAgICAgICAgICB0aGlzLnBsYXllci55ID0gbnVtO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLmxlZnQgPT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIHZhciBudW06bnVtYmVyID0gdGhpcy5wbGF5ZXIueCAtPSBkdCAqIHRoaXMuc3BlZWQ7XHJcbiAgICAgICAgICAgIHZhciBudW0yOm51bWJlciA9IHRoaXMuY2FudmFzLndpZHRoIC8gMjtcclxuICAgICAgICAgICAgbnVtID0gdGhpcy5jbGFtcChudW0sIC1udW0yLCBudW0yKTtcclxuICAgICAgICAgICAgdGhpcy5wbGF5ZXIueCA9IG51bTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5yaWdodCA9PSB0cnVlKXtcclxuICAgICAgICAgICAgdmFyIG51bTpudW1iZXIgPSB0aGlzLnBsYXllci54ICs9IGR0ICogdGhpcy5zcGVlZDtcclxuICAgICAgICAgICAgdmFyIG51bTI6bnVtYmVyID0gdGhpcy5jYW52YXMud2lkdGggLyAyO1xyXG4gICAgICAgICAgICBudW0gPSB0aGlzLmNsYW1wKG51bSwgLW51bTIsIG51bTIpO1xyXG4gICAgICAgICAgICB0aGlzLnBsYXllci54ID0gbnVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBrZXlEb3duKGV2ZW50KXtcclxuICAgICAgICBzd2l0Y2goZXZlbnQua2V5Q29kZSl7XHJcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLnc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnVwID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5zOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5kb3duID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5hOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5sZWZ0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5kOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5yaWdodCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAga2V5VXAoZXZlbnQpe1xyXG4gICAgICAgIHN3aXRjaChldmVudC5rZXlDb2RlKXtcclxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkudzpcclxuICAgICAgICAgICAgICAgIHRoaXMudXAgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5zOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5kb3duID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuYTpcclxuICAgICAgICAgICAgICAgIHRoaXMubGVmdCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLmQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJpZ2h0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY2xhbXAodmFsdWU6bnVtYmVyLCBtaW46bnVtYmVyLCAgbWF4Om51bWJlcikgOiBudW1iZXJ7XHJcbiAgICAgICAgdmFyIG51bTpudW1iZXIgPSAwO1xyXG4gICAgICAgIGlmKHZhbHVlID49IG1heCl7XHJcbiAgICAgICAgICAgIG51bSA9IG1heDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZih2YWx1ZSA8PSBtaW4pe1xyXG4gICAgICAgICAgICBudW0gPSBtaW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIG51bSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbnVtO1xyXG4gICAgfVxyXG5cclxuICAgIGZpcmUoZHQ6bnVtYmVyKXtcclxuICAgICAgICB0aGlzLmZpcmVUaW1lQ291bnQgKz0gZHQ7XHJcbiAgICAgICAgaWYodGhpcy5maXJlVGltZUNvdW50ID49IHRoaXMuZmlyZVRpbWUpe1xyXG4gICAgICAgICAgICB0aGlzLmZpcmVUaW1lQ291bnQgPSAwO1xyXG4gICAgICAgICAgICB2YXIgYnVsbGV0OmNjLk5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1bGxldCk7XHJcbiAgICAgICAgICAgIGJ1bGxldC5zZXRQYXJlbnQodGhpcy5jYW52YXMpO1xyXG4gICAgICAgICAgICBidWxsZXQuc2V0UG9zaXRpb24odGhpcy5wbGF5ZXIucG9zaXRpb24pO1xyXG4gICAgICAgICAgICBidWxsZXQuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCB0aGlzLmJ1bGxldFNwZWVkKTtcclxuICAgICAgICAgICAgYnVsbGV0LmFkZENvbXBvbmVudChCdWxsZXRDb2xsaXNpb24pLmVuZW15ID0gXCJFbmVteVwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBPbkRlc3Ryb3koKSB7XHJcbiAgICAgICAgY2MubG9nKFwicGxheWVyXCIpO1xyXG4gICAgICAgIHRoaXMubGlmdC0tO1xyXG4gICAgICAgIGlmKHRoaXMubGlmdCA8PSAwKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KFBsYXllcikuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL1Jlc3RhcnRcIikuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==