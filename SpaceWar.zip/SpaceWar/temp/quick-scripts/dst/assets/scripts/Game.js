
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9c1c5RPYWBAzZTW7xUW3HXA', 'Game');
// scripts/Game.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Player_1 = require("./Player");
var Enemy_1 = require("./Enemy");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Game = /** @class */ (function (_super) {
    __extends(Game, _super);
    function Game() {
        // LIFE-CYCLE CALLBACKS:
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.enemyList = [null, null, null, null, null, null];
        _this.enemyCount = 0;
        _this.scoreNum = 0;
        return _this;
    }
    Game.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
        cc.director.getPhysicsManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        this.canvas = cc.find("Canvas");
        this.game = cc.find("Canvas/Game");
        this.player = cc.find("Canvas/Game/Player");
        this.score = cc.find("Canvas/Game/Score");
    };
    Game.prototype.onEnable = function () {
        this.insEnemy();
        this.restartEnemy();
        this.restartPlayer();
        this.restartScore();
    };
    // start () {
    // }
    Game.prototype.update = function (dt) {
        this.detectionEnemy();
    };
    Game.prototype.insEnemy = function () {
        for (var i = this.enemyCount; i < this.enemyList.length; i++) {
            var enemy = cc.instantiate(this.enemyPrefab);
            this.enemyList[i] = enemy;
            this.enemyCount++;
        }
    };
    Game.prototype.detectionEnemy = function () {
        for (var i = 0; i < this.enemyList.length; i++) {
            if (this.enemyList[i] != null) {
                var x = Math.abs(this.enemyList[i].position.x);
                var y = this.enemyList[i].position.y;
                if (x > this.canvas.width / 2 + 100) {
                    this.setEnemy(this.enemyList[i]);
                }
                if (y < -this.canvas.height / 2) {
                    this.setEnemy(this.enemyList[i]);
                }
                if (this.enemyList[i].active == false) {
                    this.setEnemy(this.enemyList[i]);
                }
            }
        }
    };
    Game.prototype.setEnemy = function (enemy) {
        var x = this.canvas.width / 2;
        var y = this.canvas.height / 2;
        enemy.active = true;
        enemy.setParent(this.game);
        enemy.setPosition(this.random(-x, x), y, 0);
        enemy.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
        enemy.getComponent(Enemy_1.default).lift = 1;
    };
    Game.prototype.restartEnemy = function () {
        for (var i = 0; i < this.enemyList.length; i++) {
            if (this.enemyList[i] != null) {
                this.setEnemy(this.enemyList[i]);
            }
        }
    };
    Game.prototype.restartPlayer = function () {
        this.player.active = true;
        this.player.setPosition(cc.v2(0, -260));
        this.player.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
        this.player.getComponent(Player_1.default).enabled = true;
        this.player.getComponent(Player_1.default).lift = 3;
    };
    Game.prototype.restartScore = function () {
        this.scoreNum = 0;
        this.score.getComponent(cc.Label).string = "分数 : " + this.scoreNum.toString();
    };
    Game.prototype.addScore = function (num) {
        this.scoreNum += num;
        this.score.getComponent(cc.Label).string = "分数 : " + this.scoreNum.toString();
    };
    Game.prototype.random = function (min, max) {
        var r = Math.random();
        var num = 0;
        if (r < 0.5) {
            num = Math.random() * min - 50;
        }
        else {
            num = Math.random() * max + 50;
        }
        return num;
    };
    __decorate([
        property(cc.Prefab)
    ], Game.prototype, "enemyPrefab", void 0);
    Game = __decorate([
        ccclass
    ], Game);
    return Game;
}(cc.Component));
exports.default = Game;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUdsRixtQ0FBOEI7QUFDOUIsaUNBQTRCO0FBRXRCLElBQUEsa0JBQW1DLEVBQWxDLG9CQUFPLEVBQUUsc0JBQXlCLENBQUM7QUFHMUM7SUFBa0Msd0JBQVk7SUFEOUM7UUFHSSx3QkFBd0I7UUFINUIscUVBbUhDO1FBM0dHLGVBQVMsR0FBYSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDM0QsZ0JBQVUsR0FBVSxDQUFDLENBQUM7UUFPdEIsY0FBUSxHQUFVLENBQUMsQ0FBQzs7SUFtR3hCLENBQUM7SUFqR0cscUJBQU0sR0FBTjtRQUNJLEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQy9DLEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQy9DLEVBQUUsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFDMUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsdUJBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQsYUFBYTtJQUNiLElBQUk7SUFFSixxQkFBTSxHQUFOLFVBQVEsRUFBRTtRQUNOLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsdUJBQVEsR0FBUjtRQUNJLEtBQUksSUFBSSxDQUFDLEdBQVUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUM7WUFDL0QsSUFBSSxLQUFLLEdBQVcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDMUIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3JCO0lBQ0wsQ0FBQztJQUVELDZCQUFjLEdBQWQ7UUFDSSxLQUFJLElBQUksQ0FBQyxHQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUM7WUFDakQsSUFBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBQztnQkFDekIsSUFBSSxDQUFDLEdBQVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEQsSUFBSSxDQUFDLEdBQVUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUM1QyxJQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFDO29CQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDcEM7Z0JBQ0QsSUFBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUM7b0JBQzNCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNwQztnQkFDRCxJQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLEtBQUssRUFBQztvQkFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BDO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFRCx1QkFBUSxHQUFSLFVBQVMsS0FBYTtRQUNsQixJQUFJLENBQUMsR0FBVSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLEdBQVUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzNCLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDM0MsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzlELEtBQUssQ0FBQyxZQUFZLENBQUMsZUFBSyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsMkJBQVksR0FBWjtRQUNJLEtBQUksSUFBSSxDQUFDLEdBQVUsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBQztZQUNqRCxJQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFDO2dCQUN6QixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwQztTQUNKO0lBQ0wsQ0FBQztJQUVELDRCQUFhLEdBQWI7UUFDSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDaEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELDJCQUFZLEdBQVo7UUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ2xGLENBQUM7SUFFRCx1QkFBUSxHQUFSLFVBQVMsR0FBVTtRQUNmLElBQUksQ0FBQyxRQUFRLElBQUksR0FBRyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbEYsQ0FBQztJQUVELHFCQUFNLEdBQU4sVUFBTyxHQUFVLEVBQUUsR0FBVTtRQUN6QixJQUFJLENBQUMsR0FBVSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDN0IsSUFBSSxHQUFHLEdBQVUsQ0FBQyxDQUFDO1FBQ25CLElBQUcsQ0FBQyxHQUFHLEdBQUcsRUFBQztZQUNQLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQztTQUNsQzthQUNHO1lBQ0EsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDO1NBQ2xDO1FBQ0QsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0lBNUdEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7NkNBQ0U7SUFMTCxJQUFJO1FBRHhCLE9BQU87T0FDYSxJQUFJLENBa0h4QjtJQUFELFdBQUM7Q0FsSEQsQUFrSEMsQ0FsSGlDLEVBQUUsQ0FBQyxTQUFTLEdBa0g3QztrQkFsSG9CLElBQUkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5pbXBvcnQgQnVsbGV0Q29sbGlzaW9uIGZyb20gXCIuL0J1bGxldENvbGxpc2lvblwiO1xyXG5pbXBvcnQgUGxheWVyIGZyb20gXCIuL1BsYXllclwiO1xyXG5pbXBvcnQgRW5lbXkgZnJvbSBcIi4vRW5lbXlcIjtcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR2FtZSBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIGVuZW15UHJlZmFiOmNjLlByZWZhYjtcclxuXHJcbiAgICBlbmVteUxpc3Q6Y2MuTm9kZVtdID0gW251bGwsIG51bGwsIG51bGwsIG51bGwsIG51bGwsIG51bGxdO1xyXG4gICAgZW5lbXlDb3VudDpudW1iZXIgPSAwO1xyXG5cclxuICAgIHBsYXllcjpjYy5Ob2RlO1xyXG4gICAgY2FudmFzOmNjLk5vZGU7XHJcbiAgICBnYW1lOmNjLk5vZGU7XHJcblxyXG4gICAgc2NvcmU6Y2MuTm9kZTtcclxuICAgIHNjb3JlTnVtOm51bWJlciA9IDA7XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFBoeXNpY3NNYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpLmVuYWJsZWREZWJ1Z0RyYXcgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuY2FudmFzID0gY2MuZmluZChcIkNhbnZhc1wiKTtcclxuICAgICAgICB0aGlzLmdhbWUgPSBjYy5maW5kKFwiQ2FudmFzL0dhbWVcIik7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXIgPSBjYy5maW5kKFwiQ2FudmFzL0dhbWUvUGxheWVyXCIpO1xyXG4gICAgICAgIHRoaXMuc2NvcmUgPSBjYy5maW5kKFwiQ2FudmFzL0dhbWUvU2NvcmVcIik7XHJcbiAgICB9XHJcblxyXG4gICAgb25FbmFibGUoKXtcclxuICAgICAgICB0aGlzLmluc0VuZW15KCk7XHJcbiAgICAgICAgdGhpcy5yZXN0YXJ0RW5lbXkoKTtcclxuICAgICAgICB0aGlzLnJlc3RhcnRQbGF5ZXIoKTtcclxuICAgICAgICB0aGlzLnJlc3RhcnRTY29yZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHN0YXJ0ICgpIHtcclxuICAgIC8vIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdGhpcy5kZXRlY3Rpb25FbmVteSgpO1xyXG4gICAgfVxyXG5cclxuICAgIGluc0VuZW15KCl7XHJcbiAgICAgICAgZm9yKHZhciBpOm51bWJlciA9IHRoaXMuZW5lbXlDb3VudDsgaSA8IHRoaXMuZW5lbXlMaXN0Lmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgdmFyIGVuZW15OmNjLk5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmVuZW15UHJlZmFiKTtcclxuICAgICAgICAgICAgdGhpcy5lbmVteUxpc3RbaV0gPSBlbmVteTtcclxuICAgICAgICAgICAgdGhpcy5lbmVteUNvdW50Kys7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGRldGVjdGlvbkVuZW15KCl7XHJcbiAgICAgICAgZm9yKHZhciBpOm51bWJlciA9IDA7IGkgPCB0aGlzLmVuZW15TGlzdC5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuZW5lbXlMaXN0W2ldICE9IG51bGwpe1xyXG4gICAgICAgICAgICAgICAgdmFyIHg6bnVtYmVyID0gTWF0aC5hYnModGhpcy5lbmVteUxpc3RbaV0ucG9zaXRpb24ueCk7XHJcbiAgICAgICAgICAgICAgICB2YXIgeTpudW1iZXIgPSB0aGlzLmVuZW15TGlzdFtpXS5wb3NpdGlvbi55O1xyXG4gICAgICAgICAgICAgICAgaWYoeCA+IHRoaXMuY2FudmFzLndpZHRoIC8gMiArIDEwMCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRFbmVteSh0aGlzLmVuZW15TGlzdFtpXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZih5IDwgLXRoaXMuY2FudmFzLmhlaWdodCAvIDIpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RW5lbXkodGhpcy5lbmVteUxpc3RbaV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5lbmVteUxpc3RbaV0uYWN0aXZlID09IGZhbHNlKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldEVuZW15KHRoaXMuZW5lbXlMaXN0W2ldKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRFbmVteShlbmVteTpjYy5Ob2RlKXtcclxuICAgICAgICB2YXIgeDpudW1iZXIgPSB0aGlzLmNhbnZhcy53aWR0aCAvIDI7XHJcbiAgICAgICAgdmFyIHk6bnVtYmVyID0gdGhpcy5jYW52YXMuaGVpZ2h0IC8gMjtcclxuICAgICAgICBlbmVteS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIGVuZW15LnNldFBhcmVudCh0aGlzLmdhbWUpO1xyXG4gICAgICAgIGVuZW15LnNldFBvc2l0aW9uKHRoaXMucmFuZG9tKC14LCB4KSx5LCAwKTtcclxuICAgICAgICBlbmVteS5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KS5saW5lYXJWZWxvY2l0eSA9IGNjLnYyKDAsIDApO1xyXG4gICAgICAgIGVuZW15LmdldENvbXBvbmVudChFbmVteSkubGlmdCA9IDE7XHJcbiAgICB9XHJcblxyXG4gICAgcmVzdGFydEVuZW15KCl7XHJcbiAgICAgICAgZm9yKHZhciBpOm51bWJlciA9IDA7IGkgPCB0aGlzLmVuZW15TGlzdC5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuZW5lbXlMaXN0W2ldICE9IG51bGwpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRFbmVteSh0aGlzLmVuZW15TGlzdFtpXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmVzdGFydFBsYXllcigpe1xyXG4gICAgICAgIHRoaXMucGxheWVyLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0UG9zaXRpb24oY2MudjIoMCwgLTI2MCkpO1xyXG4gICAgICAgIHRoaXMucGxheWVyLmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpLmxpbmVhclZlbG9jaXR5ID0gY2MudjIoMCwgMCk7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXIuZ2V0Q29tcG9uZW50KFBsYXllcikuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXIuZ2V0Q29tcG9uZW50KFBsYXllcikubGlmdCA9IDM7XHJcbiAgICB9XHJcblxyXG4gICAgcmVzdGFydFNjb3JlKCl7XHJcbiAgICAgICAgdGhpcy5zY29yZU51bSA9IDA7XHJcbiAgICAgICAgdGhpcy5zY29yZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwi5YiG5pWwIDogXCIgKyB0aGlzLnNjb3JlTnVtLnRvU3RyaW5nKCk7XHJcbiAgICB9XHJcblxyXG4gICAgYWRkU2NvcmUobnVtOm51bWJlcil7XHJcbiAgICAgICAgdGhpcy5zY29yZU51bSArPSBudW07XHJcbiAgICAgICAgdGhpcy5zY29yZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwi5YiG5pWwIDogXCIgKyB0aGlzLnNjb3JlTnVtLnRvU3RyaW5nKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmFuZG9tKG1pbjpudW1iZXIsIG1heDpudW1iZXIpOm51bWJlcntcclxuICAgICAgICB2YXIgcjpudW1iZXIgPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIHZhciBudW06bnVtYmVyID0gMDtcclxuICAgICAgICBpZihyIDwgMC41KXtcclxuICAgICAgICAgICAgbnVtID0gTWF0aC5yYW5kb20oKSAqIG1pbiAtIDUwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBudW0gPSBNYXRoLnJhbmRvbSgpICogbWF4ICsgNTA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudW07XHJcbiAgICB9XHJcbn1cclxuIl19