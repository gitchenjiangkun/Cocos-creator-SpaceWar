
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Enemy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e9b96bkSQtDWIGL/GxT0f0m', 'Enemy');
// scripts/Enemy.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var BulletCollision_1 = require("./BulletCollision");
var AircraftBase_1 = require("./AircraftBase");
var Game_1 = require("./Game");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Enemy = /** @class */ (function (_super) {
    __extends(Enemy, _super);
    function Enemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // LIFE-CYCLE CALLBACKS:
        _this.bulletSpeed = 500;
        _this.fireTime = 0.5;
        _this.fireTimeCount = 0;
        return _this;
    }
    Enemy.prototype.onLoad = function () {
        this.canvas = cc.find("Canvas");
    };
    Enemy.prototype.start = function () {
    };
    Enemy.prototype.update = function (dt) {
        this.fire(dt);
    };
    Enemy.prototype.fire = function (dt) {
        this.fireTimeCount += dt;
        if (this.fireTimeCount >= this.fireTime) {
            this.fireTimeCount = 0;
            var bullet = cc.instantiate(this.bullet);
            bullet.setParent(this.canvas);
            bullet.setPosition(this.node.position);
            bullet.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, -this.bulletSpeed);
            bullet.addComponent(BulletCollision_1.default).enemy = "Player";
        }
    };
    Enemy.prototype.OnDestroy = function () {
        cc.log("enemy");
        this.lift--;
        if (this.lift <= 0) {
            this.node.active = false;
            var game = cc.find("Canvas/Game").getComponent(Game_1.default);
            game.addScore(1);
        }
    };
    __decorate([
        property(cc.Prefab)
    ], Enemy.prototype, "bullet", void 0);
    Enemy = __decorate([
        ccclass
    ], Enemy);
    return Enemy;
}(AircraftBase_1.default));
exports.default = Enemy;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRW5lbXkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFbEYscURBQWdEO0FBQ2hELCtDQUEwQztBQUMxQywrQkFBMEI7QUFFcEIsSUFBQSxrQkFBbUMsRUFBbEMsb0JBQU8sRUFBRSxzQkFBeUIsQ0FBQztBQUcxQztJQUFtQyx5QkFBWTtJQUQvQztRQUFBLHFFQTZDQztRQXZDRyx3QkFBd0I7UUFDeEIsaUJBQVcsR0FBVSxHQUFHLENBQUM7UUFDekIsY0FBUSxHQUFVLEdBQUcsQ0FBQztRQUN0QixtQkFBYSxHQUFVLENBQUMsQ0FBQzs7SUFvQzdCLENBQUM7SUFqQ0ksc0JBQU0sR0FBTjtRQUNHLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRUYscUJBQUssR0FBTDtJQUVBLENBQUM7SUFFQSxzQkFBTSxHQUFOLFVBQVEsRUFBRTtRQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDakIsQ0FBQztJQUVGLG9CQUFJLEdBQUosVUFBSyxFQUFTO1FBQ1YsSUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUM7UUFDekIsSUFBRyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUM7WUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7WUFDdkIsSUFBSSxNQUFNLEdBQVcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDOUIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3ZDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMvRSxNQUFNLENBQUMsWUFBWSxDQUFDLHlCQUFlLENBQUMsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO1NBQ3pEO0lBQ0wsQ0FBQztJQUVELHlCQUFTLEdBQVQ7UUFDSSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNaLElBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLEVBQUM7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDekIsSUFBSSxJQUFJLEdBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBSSxDQUFDLENBQUM7WUFDMUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNwQjtJQUNMLENBQUM7SUF4Q0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzt5Q0FDSDtJQUhBLEtBQUs7UUFEekIsT0FBTztPQUNhLEtBQUssQ0E0Q3pCO0lBQUQsWUFBQztDQTVDRCxBQTRDQyxDQTVDa0Msc0JBQVksR0E0QzlDO2tCQTVDb0IsS0FBSyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmltcG9ydCBCdWxsZXRDb2xsaXNpb24gZnJvbSBcIi4vQnVsbGV0Q29sbGlzaW9uXCI7XHJcbmltcG9ydCBBaXJjcmFmdEJhc2UgZnJvbSBcIi4vQWlyY3JhZnRCYXNlXCI7XHJcbmltcG9ydCBHYW1lIGZyb20gXCIuL0dhbWVcIjtcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgRW5lbXkgZXh0ZW5kcyBBaXJjcmFmdEJhc2V7XHJcbiAgICBcclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBidWxsZXQ6Y2MuUHJlZmFiO1xyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG4gICAgYnVsbGV0U3BlZWQ6bnVtYmVyID0gNTAwO1xyXG4gICAgZmlyZVRpbWU6bnVtYmVyID0gMC41O1xyXG4gICAgZmlyZVRpbWVDb3VudDpudW1iZXIgPSAwO1xyXG5cclxuICAgIGNhbnZhczpjYy5Ob2RlO1xyXG4gICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgdGhpcy5jYW52YXMgPSBjYy5maW5kKFwiQ2FudmFzXCIpO1xyXG4gICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdGhpcy5maXJlKGR0KTtcclxuICAgICB9XHJcblxyXG4gICAgZmlyZShkdDpudW1iZXIpe1xyXG4gICAgICAgIHRoaXMuZmlyZVRpbWVDb3VudCArPSBkdDtcclxuICAgICAgICBpZih0aGlzLmZpcmVUaW1lQ291bnQgPj0gdGhpcy5maXJlVGltZSl7XHJcbiAgICAgICAgICAgIHRoaXMuZmlyZVRpbWVDb3VudCA9IDA7XHJcbiAgICAgICAgICAgIHZhciBidWxsZXQ6Y2MuTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0KTtcclxuICAgICAgICAgICAgYnVsbGV0LnNldFBhcmVudCh0aGlzLmNhbnZhcyk7XHJcbiAgICAgICAgICAgIGJ1bGxldC5zZXRQb3NpdGlvbih0aGlzLm5vZGUucG9zaXRpb24pO1xyXG4gICAgICAgICAgICBidWxsZXQuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCAtdGhpcy5idWxsZXRTcGVlZCk7XHJcbiAgICAgICAgICAgIGJ1bGxldC5hZGRDb21wb25lbnQoQnVsbGV0Q29sbGlzaW9uKS5lbmVteSA9IFwiUGxheWVyXCI7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIE9uRGVzdHJveSgpIHtcclxuICAgICAgICBjYy5sb2coXCJlbmVteVwiKTtcclxuICAgICAgICB0aGlzLmxpZnQtLTtcclxuICAgICAgICBpZih0aGlzLmxpZnQgPD0gMCl7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdmFyIGdhbWU6R2FtZSA9IGNjLmZpbmQoXCJDYW52YXMvR2FtZVwiKS5nZXRDb21wb25lbnQoR2FtZSk7XHJcbiAgICAgICAgICAgIGdhbWUuYWRkU2NvcmUoMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==