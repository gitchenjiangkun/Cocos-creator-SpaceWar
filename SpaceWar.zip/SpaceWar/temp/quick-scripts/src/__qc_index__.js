
require('./assets/scripts/AircraftBase');
require('./assets/scripts/BulletCollision');
require('./assets/scripts/Enemy');
require('./assets/scripts/Game');
require('./assets/scripts/IDestroy');
require('./assets/scripts/Menu');
require('./assets/scripts/Player');
require('./assets/scripts/Restart');
require('./assets/scripts/UrlButton');
