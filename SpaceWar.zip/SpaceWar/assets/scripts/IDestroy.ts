
 interface IDestroy{
    OnDestroy();
}
